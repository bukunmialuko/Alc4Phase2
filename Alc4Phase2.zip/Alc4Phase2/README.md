# Alc4Phase2
An android app that  help user find holiday deals.


You have to generate your own google-services.json file and include it in the app folder.